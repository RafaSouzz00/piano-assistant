# Piano Assistant — protótipo v1

Este pacote contém a primeira entrega funcional do Piano Assistant como PWA (aplicativo web instalável).

## Incluído
- Interface responsiva com cinco abas.
- Teoria musical inicial: campo harmônico de Dó maior e dicionário de acordes.
- Teclado virtual de uma oitava com áudio sintetizado.
- Cadastro local de músicas em estudo.
- Registro de sessões, sequência de dias e diário musical.
- Metrônomo ajustável.
- Manifesto PWA e service worker.

## Limitações conhecidas
- Ainda não contém detector de notas ou acordes pelo microfone.
- Ainda não contém análise de execução.
- O conteúdo musical é uma amostra inicial, não um curso completo.
- Os dados ficam no armazenamento local do navegador deste dispositivo. Limpar os dados do site pode apagá-los.
- A instalação PWA depende de hospedagem HTTPS.
- O service worker exige servidor HTTPS ou localhost.

## Como abrir no iPhone
1. Importe os arquivos para um projeto de aplicação web em um ambiente de desenvolvimento online.
2. Execute e publique o projeto em uma URL HTTPS.
3. Abra a URL no Safari do iPhone.
4. Use Compartilhar > Adicionar à Tela de Início.
5. Ative "Abrir como App" se a opção aparecer.

## Estrutura
- index.html — interface e lógica da primeira versão.
- manifest.webmanifest — metadados PWA.
- sw.js — cache básico do aplicativo.
